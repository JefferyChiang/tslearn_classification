pytest joblib --cov joblib -vl --timeout 30 --ignore joblib/externals
exit $LastExitCode
